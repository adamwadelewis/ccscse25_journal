zip -r paper_template.zip paper_template
zip -r other_template.zip other_template

